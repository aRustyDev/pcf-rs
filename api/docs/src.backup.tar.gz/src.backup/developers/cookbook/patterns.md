# Common Patterns
